import { combineReducers } from "redux";

import tabReducer from "./tab/tabReducer";

export default combineReducers({
    tabReducer
});